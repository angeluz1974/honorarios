-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 11-10-2018 a las 23:17:22
-- Versión del servidor: 10.1.26-MariaDB-0+deb9u1
-- Versión de PHP: 7.0.30-0+deb9u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `caez`
--
CREATE DATABASE IF NOT EXISTS `caez` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `caez`;

DELIMITER $$
--
-- Procedimientos
--
DROP PROCEDURE IF EXISTS `add_categoria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_categoria` (`cdescrip` VARCHAR(254), `ctipo` VARCHAR(15))  BEGIN
 insert into hon_categorias values (0,cdescrip,ctipo);
 end$$

DROP PROCEDURE IF EXISTS `add_documento`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_documento` (`ccod` VARCHAR(15), `cdescrip` VARCHAR(65), `nprecio` DECIMAL(12,2), `ctipo` VARCHAR(15))  BEGIN
 insert into hon_documentos values (0,ccod,cdescrip,nprecio,ctipo);
 end$$

DROP PROCEDURE IF EXISTS `add_opciones`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_opciones` (`ccod` VARCHAR(15), `cnombre` VARCHAR(65), `cvalor` VARCHAR(65))  BEGIN
 insert into hon_opciones values (0,ccod,cnombre,cvalor);
 end$$

DROP PROCEDURE IF EXISTS `add_tarifas`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_tarifas` (`ncategoria` INT, `ndesde` DECIMAL(12,2), `nhasta` DECIMAL(12,2), `nporc` DECIMAL(3,2))  BEGIN
 insert into hon_tarifas values (0,ncategoria,ndesde,nhasta,nporc);
 end$$

DROP PROCEDURE IF EXISTS `delete_categoria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_categoria` (`nid` INT)  BEGIN
 delete from hon_categorias where id_categoria=nid;
 end$$

DROP PROCEDURE IF EXISTS `delete_documentos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_documentos` (`nid` INT)  BEGIN
 delete from hon_documentos where id_documento=nid;
 end$$

DROP PROCEDURE IF EXISTS `delete_opciones`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_opciones` (`nid` INT)  BEGIN
 delete from hon_opciones where id_opcion=nid;
 end$$

DROP PROCEDURE IF EXISTS `delete_tarifas`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_tarifas` (`nid` INT)  BEGIN
 delete from hon_tarifas where id_tarifa=nid;
 end$$

DROP PROCEDURE IF EXISTS `del_categoria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_categoria` (IN `nid` INT)  BEGIN
delete from hon_categorias where id_categori=nid;
END$$

DROP PROCEDURE IF EXISTS `del_documento`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_documento` (IN `nid` INT)  BEGIN
delete from hon_documentos where id_documento=nid;
END$$

DROP PROCEDURE IF EXISTS `update_categoria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_categoria` (`nid` INT, `cdescrip` VARCHAR(254), `ctipo` VARCHAR(15))  BEGIN
 update hon_categorias set descripcion=cdescrip,cod_tipo=ctipo where id_categoria=nid;
 end$$

DROP PROCEDURE IF EXISTS `update_documento`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_documento` (`nid` INT, `ccod` VARCHAR(15), `cdescrip` VARCHAR(65), `nprecio` DECIMAL(12,2), `ctipo` VARCHAR(15))  BEGIN
 update hon_documentos set cod_documento=ccod,descripcion=cdescrip,precio=nprecio,hon_tipo=ctipo where id_documento=nid;
 end$$

DROP PROCEDURE IF EXISTS `update_opciones`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_opciones` (`nid` INT, `ccod` VARCHAR(15), `cnombre` VARCHAR(65), `cvalor` VARCHAR(65))  BEGIN
 update hon_opciones set codigo_opcion=ccod,nombre_opcion=cnombre,valor_opcion=cvalor where id_opcion=nid;
 end$$

DROP PROCEDURE IF EXISTS `update_tarifas`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_tarifas` (`nid` INT, `ncategoria` INT, `ndesde` DECIMAL(12,2), `nhasta` DECIMAL(12,2), `nporc` DECIMAL(3,2))  BEGIN
 update hon_tarifas set id_categoria=ncategoria,desde=ndesde,hasta=nhasta,porcentaje=nporc where id_tarifa=nid;
 end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hon_abogados`
--

DROP TABLE IF EXISTS `hon_abogados`;
CREATE TABLE `hon_abogados` (
  `id_abogado` int(11) NOT NULL,
  `cod_abogado` int(11) NOT NULL,
  `cod_inpre` int(11) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `dir_habitacion` varchar(120) NOT NULL,
  `tel_habitacion` varchar(15) NOT NULL,
  `celular` varchar(15) NOT NULL,
  `email` varchar(120) NOT NULL,
  `fecha_actualiza` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hon_categorias`
--

DROP TABLE IF EXISTS `hon_categorias`;
CREATE TABLE `hon_categorias` (
  `id_categoria` int(11) NOT NULL,
  `descripcion` varchar(254) NOT NULL,
  `cod_tipo` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `hon_categorias`
--

INSERT INTO `hon_categorias` (`id_categoria`, `descripcion`, `cod_tipo`) VALUES
(1, 'ARTICULO 4                                                                                                                                                                                                                                                    ', '               '),
(2, 'ART. 4 PARR. 1                                                                                                                                                                                                                                                ', '               ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hon_documentos`
--

DROP TABLE IF EXISTS `hon_documentos`;
CREATE TABLE `hon_documentos` (
  `id_documento` int(11) NOT NULL,
  `cod_documento` varchar(15) NOT NULL,
  `descripcion` varchar(65) NOT NULL,
  `precio` decimal(12,2) NOT NULL,
  `hon_tipo` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hon_opciones`
--

DROP TABLE IF EXISTS `hon_opciones`;
CREATE TABLE `hon_opciones` (
  `id_opcion` int(11) NOT NULL,
  `codigo_opcion` varchar(15) NOT NULL,
  `nombre_opcion` varchar(65) NOT NULL,
  `valor_opcion` varchar(65) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `hon_opciones`
--

INSERT INTO `hon_opciones` (`id_opcion`, `codigo_opcion`, `nombre_opcion`, `valor_opcion`) VALUES
(1, 'HON_TAQ', 'SEDE CAJA 36', '0136'),
(2, 'HON_TAQ', 'SEDE CAJA 37', '0137'),
(3, 'HON_TIPO', 'HONORARIOS COMPLETOS', '1'),
(4, 'HON_TIPO', 'DERECHOS ESPECIALES', '2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hon_pagos`
--

DROP TABLE IF EXISTS `hon_pagos`;
CREATE TABLE `hon_pagos` (
  `id_pago` int(11) NOT NULL DEFAULT '0',
  `fecha_pago` datetime NOT NULL,
  `id_abogado` int(11) NOT NULL,
  `id_documento` int(11) NOT NULL,
  `precio` decimal(12,2) NOT NULL DEFAULT '0.00',
  `honorarios` decimal(12,2) NOT NULL,
  `status` varchar(15) NOT NULL,
  `fecha_actualiza` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hon_tarifas`
--

DROP TABLE IF EXISTS `hon_tarifas`;
CREATE TABLE `hon_tarifas` (
  `id_tarifa` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `desde` decimal(12,2) NOT NULL,
  `hasta` decimal(12,2) NOT NULL,
  `porcentaje` decimal(3,2) NOT NULL,
  `fecha_crea` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualiza` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hon_usuarios`
--

DROP TABLE IF EXISTS `hon_usuarios`;
CREATE TABLE `hon_usuarios` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(15) NOT NULL,
  `clave` varchar(120) NOT NULL,
  `nombres` varchar(25) NOT NULL,
  `apellidos` varchar(25) NOT NULL,
  `taquilla` varchar(6) NOT NULL,
  `activo` tinyint(4) NOT NULL,
  `fecha_crea` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_accesa` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `hon_usuarios`
--

INSERT INTO `hon_usuarios` (`id_usuario`, `usuario`, `clave`, `nombres`, `apellidos`, `taquilla`, `activo`, `fecha_crea`, `fecha_accesa`) VALUES
(1, 'amata', '*2F8BC55CBEAC413C3DEB65AD40D0E6E1FFE6E579', 'ANGEL', 'MATA', '999999', 1, '2018-09-27 23:45:42', '0000-00-00 00:00:00');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `hon_abogados`
--
ALTER TABLE `hon_abogados`
  ADD PRIMARY KEY (`id_abogado`);

--
-- Indices de la tabla `hon_categorias`
--
ALTER TABLE `hon_categorias`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `hon_documentos`
--
ALTER TABLE `hon_documentos`
  ADD PRIMARY KEY (`id_documento`);

--
-- Indices de la tabla `hon_opciones`
--
ALTER TABLE `hon_opciones`
  ADD PRIMARY KEY (`id_opcion`);

--
-- Indices de la tabla `hon_pagos`
--
ALTER TABLE `hon_pagos`
  ADD PRIMARY KEY (`id_pago`);

--
-- Indices de la tabla `hon_tarifas`
--
ALTER TABLE `hon_tarifas`
  ADD PRIMARY KEY (`id_tarifa`);

--
-- Indices de la tabla `hon_usuarios`
--
ALTER TABLE `hon_usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `hon_abogados`
--
ALTER TABLE `hon_abogados`
  MODIFY `id_abogado` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `hon_categorias`
--
ALTER TABLE `hon_categorias`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `hon_documentos`
--
ALTER TABLE `hon_documentos`
  MODIFY `id_documento` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `hon_opciones`
--
ALTER TABLE `hon_opciones`
  MODIFY `id_opcion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `hon_tarifas`
--
ALTER TABLE `hon_tarifas`
  MODIFY `id_tarifa` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `hon_usuarios`
--
ALTER TABLE `hon_usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
